import os
import json
import asyncio
import uuid
import sys
import subprocess
from datetime import datetime
from aiohttp import web
from mcp.server import Server, NotificationOptions
from mcp.server.stdio import stdio_server
import mcp.types as mcp_types
from lxml import etree
from colorama import init, Fore, Style

# Initialize colorama
init(autoreset=True)

# Shared State
class SharedState:
    def __init__(self):
        self.task_queue = asyncio.Queue()
        self.results = {}  # task_id -> {"success": bool, "error": str, "event": asyncio.Event}
        self.last_poll_time = None
        self.status_lock = asyncio.Lock()
        self.drafts = {} # session_id -> DraftDiagram
        self.phase_plans = {} # session_id -> {"phases": list[str], "completed": list[str]}

state = SharedState()

# Absolute pathing for data directory
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(BASE_DIR, "data")
PORT_REGISTRY_PATH = os.path.join(DATA_DIR, "blocks", "port_registry.json")

# --- Incremental Draft Management ---

class DraftDiagram:
    def __init__(self, schema_version="1.1"):
        self.schema_version = schema_version
        self.blocks = []
        self.links = []
        self.created_at = datetime.now()

    def add_blocks(self, xml_chunk):
        self.blocks.append(xml_chunk)

    def add_links(self, xml_chunk):
        self.links.append(xml_chunk)

    def to_xml(self):
        """Assembles the full Xcos XML from parts compatible with Scilab 2026.0.1."""
        # Skeleton boilerplate based on Scilab 2026 empty.xcos
        full_xml = f'<?xml version="1.0" encoding="UTF-8"?>\n'
        full_xml += '<XcosDiagram background="-1" gridEnabled="1" title="Untitled" '
        full_xml += 'finalIntegrationTime="100000.0" integratorAbsoluteTolerance="1.0E-6" '
        full_xml += 'integratorRelativeTolerance="1.0E-6" toleranceOnTime="1.0E-10" '
        full_xml += 'maxIntegrationTimeInterval="100001.0" maximumStepSize="0.0" '
        full_xml += 'realTimeScaling="1.0" solver="0.0">\n'
        full_xml += '  <Array as="context" scilabClass="String[]"></Array>\n'
        full_xml += '  <mxGraphModel as="model" grid="1" guides="1" tooltips="1" connect="1" arrows="1" fold="1" page="1" pageScale="1" pageWidth="850" pageHeight="1100" background="#ffffff">\n'
        full_xml += '    <root>\n'
        full_xml += '      <mxCell id="0"/>\n'
        full_xml += '      <mxCell id="1" parent="0"/>\n'
        
        # Append blocks and links
        for b in self.blocks:
            full_xml += f'      {b}\n'
        for l in self.links:
            full_xml += f'      {l}\n'
            
        full_xml += '    </root>\n'
        full_xml += '  </mxGraphModel>\n'
        full_xml += '</XcosDiagram>'
        return full_xml

# --- Xcos Validation & Auto-fix Helpers ---

def load_port_registry():
    if os.path.exists(PORT_REGISTRY_PATH):
        with open(PORT_REGISTRY_PATH, 'r', encoding='utf-8') as f:
            return json.load(f)
    return {}

PORT_REGISTRY = load_port_registry()
SCALAR_INPUT_BLOCKS = {"CANIMXY", "CANIMXY3D", "BARXY", "CSCOPXY", "CSCOPXY3D"}

def auto_fix_mux_to_scalar(tree):
    """
    Finds MUX blocks connected to scalar-only input blocks and bypasses them.
    If a MUX with N inputs is connected to a destination block that expects 
    multiple scalar inputs (like CANIMXY), it replaces the MUX link with 
    direct links from MUX inputs.
    """
    # Find all MUX blocks
    mux_blocks = tree.xpath("//BasicBlock[@interfaceFunctionName='MUX' or @interfaceFunctionName='MUX_f']")
    links_to_remove = []
    blocks_to_remove = set()
    new_links = []

    for mux in mux_blocks:
        mux_id = mux.get("id")
        # Find output port of this MUX
        mux_out_port = mux.xpath("./ExplicitOutputPort")
        if not mux_out_port: continue
        mux_out_id = mux_out_port[0].get("id")

        # Find link from this MUX output
        link_from_mux = tree.xpath(f"//BasicLink[SourcePort/@reference='{mux_out_id}']")
        if not link_from_mux: continue
        
        link = link_from_mux[0]
        dst_port_ref = link.xpath("./DestinationPort/@reference")[0]
        dst_port = tree.xpath(f"//*[@id='{dst_port_ref}']")[0]
        dst_block = dst_port.getparent()
        dst_interface = dst_block.get("interfaceFunctionName")

        if dst_interface in SCALAR_INPUT_BLOCKS:
            # We found a MUX -> Scalar block link.
            # Mirror the manual fix: Bypass the MUX.
            # Get MUX input links
            mux_in_ports = mux.xpath("./ExplicitInputPort")
            # Ordering them by 'ordering' attribute
            mux_in_ports.sort(key=lambda p: int(p.get("ordering", "0")))
            
            # Destination ports of the destination block
            dst_in_ports = dst_block.xpath("./ExplicitInputPort")
            dst_in_ports.sort(key=lambda p: int(p.get("ordering", "0")))

            # Connect MUX inputs to Destination inputs
            for i, mux_in_p in enumerate(mux_in_ports):
                if i >= len(dst_in_ports): break
                
                mux_in_id = mux_in_p.get("id")
                # Find the link coming into the MUX
                incoming_link = tree.xpath(f"//BasicLink[DestinationPort/@reference='{mux_in_id}']")
                if incoming_link:
                    # Point the incoming link directly to the destination block port
                    incoming_src_ref = incoming_link[0].xpath("./SourcePort/@reference")[0]
                    
                    # Create a new link replacing the incoming + mux + outgoing chain
                    link_parent = link.get("parent") or mux.get("parent") or "0:2:0"
                    new_link = etree.Element("BasicLink", id=str(uuid.uuid4()), parent=link_parent,
                                            style=link.get("style") or "noEdgeStyle=1;orthogonal=1;")
                    etree.SubElement(new_link, "mxGeometry", as_="geometry")
                    etree.SubElement(new_link, "SourcePort", as_="source", reference=incoming_src_ref)
                    etree.SubElement(new_link, "DestinationPort", as_="target", reference=dst_in_ports[i].get("id"))
                    new_links.append(new_link)
                    
                    links_to_remove.append(incoming_link[0])
            
            links_to_remove.append(link)
            blocks_to_remove.add(mux)

    # Apply changes
    graph_root = tree.xpath("//mxGraphModel/root")[0]
    for link in links_to_remove:
        if link.getparent() is not None:
            link.getparent().remove(link)
    for block in blocks_to_remove:
        if block.getparent() is not None:
            block.getparent().remove(block)
    for nl in new_links:
        graph_root.append(nl)
    
    return len(blocks_to_remove) > 0

def validate_port_sizes(tree):
    """
    Parses the Xcos XML tree to extract port info and validates it against 
    the PORT_REGISTRY and link consistency. Supports wildcards (-1, -2).
    """
    errors = []
    
    # Helper to check if dimensions match, respecting Scilab wildcards (-1, -2)
    def dims_match(actual, expected):
        if not actual or not expected: return True
        if len(actual) != len(expected): return False
        for a, e in zip(actual, expected):
            # If either side is negative, it's a wildcard matching anything
            if a < 0 or e < 0: continue 
            if a != e: return False
        return True

    # 1. Collect all port definitions from the XML
    ports = {} # id -> {size: [rows, cols], blockId: str, interface: str, kind: in/out, index: int}
    all_ports = tree.xpath("//ExplicitInputPort | //ExplicitOutputPort")
    for p in all_ports:
        pid = p.get("id")
        block = p.getparent()
        kind = "input" if "Input" in p.tag else "output"
        ports[pid] = {
            "size": [int(p.get("dataLines", 1)), int(p.get("dataColumns", 1))],
            "blockId": block.get("id"),
            "interface": block.get("interfaceFunctionName"),
            "kind": kind,
            "index": int(p.get("ordering", 1))
        }

    # 2. Cross-check against Registry
    for pid, pdata in ports.items():
        reg = PORT_REGISTRY.get(pdata["interface"])
        if reg:
            expected_ports = reg.get("inputs" if pdata["kind"] == "input" else "outputs")
            
            # Skip validation for variadic blocks (logic for these is usually parameter-dependent)
            if expected_ports == "variadic":
                continue
                
            if expected_ports and pdata["index"] <= len(expected_ports):
                expected_size = expected_ports[pdata["index"] - 1]
                if not dims_match(pdata["size"], expected_size):
                    errors.append({
                        "type": "REGISTRY_SIZE_MISMATCH",
                        "block": pdata["interface"],
                        "blockId": pdata["blockId"],
                        "portKind": pdata["kind"],
                        "portIndex": pdata["index"],
                        "expectedSize": expected_size,
                        "actualSize": pdata["size"]
                    })

    # 3. Validate Link consistency (src size must match dst size unless wildcard)
    links = tree.xpath("//BasicLink")
    for link in links:
        src_ref = link.xpath("./SourcePort/@reference")
        dst_ref = link.xpath("./DestinationPort/@reference")
        if not src_ref or not dst_ref: continue
        
        src_port = ports.get(src_ref[0])
        dst_port = ports.get(dst_ref[0])
        
        if src_port and dst_port:
            if not dims_match(src_port["size"], dst_port["size"]):
                errors.append({
                    "type": "PORT_SIZE_MISMATCH",
                    "srcBlock": src_port["interface"],
                    "dstBlock": dst_port["interface"],
                    "srcPort": src_port["index"],
                    "dstPort": dst_port["index"],
                    "srcSize": src_port["size"],
                    "dstSize": dst_port["size"],
                    "linkId": link.get("id")
                })
    
    return errors


# --- Ensure Directories Exist ---
os.makedirs(os.path.join(DATA_DIR, "temp"), exist_ok=True)

# --- MCP Tool Implementations ---

async def get_xcos_block_source(name: str):
    # Recursive search for {name}.sci in ./data/macros/
    macros_dir = os.path.join(DATA_DIR, "macros")
    for root, dirs, files in os.walk(macros_dir):
        if f"{name}.sci" in files:
            path = os.path.join(root, f"{name}.sci")
            with open(path, 'r', encoding='utf-8') as f:
                return [mcp_types.TextContent(type="text", text=f.read())]
    return [mcp_types.TextContent(type="text", text=f"Error: Source for '{name}' not found in {macros_dir}")]

async def get_xcos_block_data(name: str):
    """Returns annotation JSON, reference XML, and parameter help for an Xcos block."""
    results = []
    
    # 1. INFO (from get_xcos_block_info logic)
    info_path = os.path.join(DATA_DIR, "blocks", f"{name}.json")
    if os.path.exists(info_path):
        with open(info_path, 'r', encoding='utf-8') as f:
            results.append(f"=== INFO ===\n{f.read()}")
    else:
        results.append(f"=== INFO ===\nError: Block info for '{name}' not found at {info_path}")

    # 2. EXAMPLE (from get_xcos_block_example logic)
    example_path = os.path.join(DATA_DIR, "reference_blocks", f"{name}.xcos")
    if os.path.exists(example_path):
        with open(example_path, 'r', encoding='utf-8') as f:
            results.append(f"=== EXAMPLE ===\n{f.read()}")
    else:
        results.append(f"=== EXAMPLE ===\nError: Reference block '{name}' not found at {example_path}")

    # 3. HELP (from get_xcos_block_help logic)
    help_file = None
    search_dir = os.path.join(DATA_DIR, "help")
    for root, dirs, files in os.walk(search_dir):
        if f"{name}.xml" in files:
            help_file = os.path.join(root, f"{name}.xml")
            break
    
    if not help_file:
        results.append(f"=== HELP ===\nError: Help file for '{name}' not found in {search_dir}")
    else:
        try:
            parser = etree.XMLParser(remove_blank_text=True)
            tree = etree.parse(help_file, parser)
            sections = tree.xpath("//*[local-name()='refsection']")
            extracted_text = []
            for section in sections:
                sec_id = section.get("{http://www.w3.org/XML/1998/namespace}id") or section.get("id")
                if sec_id and (sec_id.startswith("Dialogbox_") or sec_id.startswith("Defaultproperties_")):
                    title = section.xpath("string(.)").strip()
                    extracted_text.append(f"--- Section: {sec_id} ---\n{title}")

            if not extracted_text:
                results.append(f"=== HELP ===\nNo parameter sections found in {help_file}")
            else:
                results.append(f"=== HELP ===\n" + "\n\n".join(extracted_text))
        except Exception as e:
            results.append(f"=== HELP ===\nError parsing help XML: {str(e)}")

    return [mcp_types.TextContent(type="text", text="\n\n".join(results))]

async def search_related_xcos_files(query: str):
    results = []
    for root, dirs, files in os.walk(DATA_DIR):
        for file in files:
            if query.lower() in file.lower():
                results.append(os.path.join(root, file))
    
    if not results:
        return [mcp_types.TextContent(type="text", text=f"No files matching '{query}' found in {DATA_DIR}")]
    
    return [mcp_types.TextContent(type="text", text="\n".join(results))]

async def verify_xcos_xml(xml_content: str):
    # --- Integration of Auto-fix and Validator ---
    try:
        parser = etree.XMLParser(remove_blank_text=True)
        tree = etree.fromstring(xml_content.encode('utf-8'), parser)
        
        # 1. Auto-fix
        auto_fixed = auto_fix_mux_to_scalar(tree)
        if auto_fixed:
            xml_content = etree.tostring(tree, encoding='unicode', pretty_print=True)
        
        # 2. Pre-simulation Validation
        val_errors = validate_port_sizes(tree)
        if val_errors:
            return [mcp_types.TextContent(type="text", text=json.dumps({
                "success": False,
                "origin": "pre-sim-validator",
                "errors": val_errors
            }, indent=2))]
            
    except Exception as e:
        return [mcp_types.TextContent(type="text", text=f"Error during pre-validation: {str(e)}")]

    task_id = str(uuid.uuid4())
    temp_path = os.path.join(DATA_DIR, "temp", f"{task_id}.xcos")
    
    with open(temp_path, 'w', encoding='utf-8') as f:
        f.write(xml_content)
    
    event = asyncio.Event()
    state.results[task_id] = {"success": False, "error": "", "event": event}
    
    await state.task_queue.put({"task_id": task_id, "zcos_path": temp_path})
    
    try:
        # Wait for 120 seconds
        await asyncio.wait_for(event.wait(), timeout=120.0)
        res = state.results.pop(task_id)
        
        # Structured result
        result_payload = {
            "success": res["success"],
            "task_id": task_id,
        }
        if not res["success"]:
            result_payload["error"] = res["error"]
            # Potentially parse Scilab error string here to make it even more structured
        
        return [mcp_types.TextContent(type="text", text=json.dumps(result_payload, indent=2))]
        
    except asyncio.TimeoutError:
        state.results.pop(task_id, None)
        return [mcp_types.TextContent(type="text", text=json.dumps({
            "success": False,
            "error": f"Scilab verification timed out for {task_id}"
        }, indent=2))]

# --- Incremental Tool Implementations ---

async def xcos_start_draft(schema_version: str = "1.1"):
    session_id = str(uuid.uuid4())
    state.drafts[session_id] = DraftDiagram(schema_version)
    return [mcp_types.TextContent(type="text", text=json.dumps({
        "status": "success",
        "session_id": session_id,
        "message": f"Started new Xcos draft session {session_id}"
    }, indent=2))]

async def xcos_add_blocks(session_id: str, blocks_xml: str):
    if session_id not in state.drafts:
        return [mcp_types.TextContent(type="text", text=f"Error: Session {session_id} not found")]
    state.drafts[session_id].add_blocks(blocks_xml)
    return [mcp_types.TextContent(type="text", text=f"Successfully added blocks to session {session_id}")]

async def xcos_add_links(session_id: str, links_xml: str):
    if session_id not in state.drafts:
        return [mcp_types.TextContent(type="text", text=f"Error: Session {session_id} not found")]
    state.drafts[session_id].add_links(links_xml)
    return [mcp_types.TextContent(type="text", text=f"Successfully added links to session {session_id}")]

async def xcos_verify_draft(session_id: str):
    if session_id not in state.drafts:
        return [mcp_types.TextContent(type="text", text=f"Error: Session {session_id} not found")]
    
    draft = state.drafts[session_id]
    xml_content = draft.to_xml()
    
    # Use the existing verification logic
    return await verify_xcos_xml(xml_content)

async def xcos_plan_phases(session_id: str, phases: list[str]):
    if session_id not in state.drafts:
        state.drafts[session_id] = DraftDiagram()
    
    state.phase_plans[session_id] = {
        "phases": phases,
        "completed": []
    }
    return [mcp_types.TextContent(type="text", text=json.dumps({
        "status": "success",
        "phase_count": len(phases),
        "labels": phases
    }, indent=2))]

async def xcos_commit_phase(session_id: str, phase_label: str, blocks_xml: str):
    if session_id not in state.drafts:
        return [mcp_types.TextContent(type="text", text=f"Error: Session {session_id} not found")]
    
    if session_id not in state.phase_plans:
        return [mcp_types.TextContent(type="text", text=f"Error: No phase plan found for session {session_id}. Call xcos_plan_phases first.")]
    
    plan = state.phase_plans[session_id]
    if phase_label not in plan["phases"]:
        return [mcp_types.TextContent(type="text", text=f"Error: Phase '{phase_label}' not found in the plan.")]
    
    # Append blocks
    state.drafts[session_id].add_blocks(blocks_xml)
    
    # Mark as complete (avoid duplicates if re-committed)
    if phase_label not in plan["completed"]:
        plan["completed"].append(phase_label)
    
    # Write full accumulated .xcos file to disk
    session_dir = os.path.join(BASE_DIR, "sessions", session_id)
    os.makedirs(session_dir, exist_ok=True)
    
    file_path = os.path.join(session_dir, "diagram.xcos")
    full_xml = state.drafts[session_id].to_xml()
    
    with open(file_path, 'w', encoding='utf-8') as f:
        f.write(full_xml)
    
    file_size = os.path.getsize(file_path)
    
    completed_count = len(plan["completed"])
    total_count = len(plan["phases"])
    remaining = [p for p in plan["phases"] if p not in plan["completed"]]
    
    return [mcp_types.TextContent(type="text", text=json.dumps({
        "status": "success",
        "completed_count": completed_count,
        "total_count": total_count,
        "remaining_phases": remaining,
        "written_to": file_path,
        "file_size_bytes": file_size
    }, indent=2))]

# --- HTTP Polling Bridge ---

async def handle_get_task(request):
    try:
        task = state.task_queue.get_nowait()
        state.last_poll_time = datetime.now()
        return web.json_response({"status": "pending", **task})
    except asyncio.QueueEmpty:
        state.last_poll_time = datetime.now()
        return web.json_response({"status": "idle"})

async def handle_post_result(request):
    data = await request.json()
    task_id = data.get("task_id")
    success = data.get("success")
    error = data.get("error", "")
    
    if task_id in state.results:
        state.results[task_id]["success"] = success
        state.results[task_id]["error"] = error
        state.results[task_id]["event"].set()
        return web.json_response({"status": "received"})
    else:
        return web.json_response({"status": "error", "message": "Task ID not found"}, status=404)

async def cleanup_port(port=8000):
    """Kills any process currently using the specified port on Windows."""
    try:
        # Find PID using netstat
        cmd = f'netstat -ano | findstr :{port}'
        output = subprocess.check_output(cmd, shell=True).decode()
        for line in output.splitlines():
            if "LISTENING" in line:
                pid = line.strip().split()[-1]
                if int(pid) != os.getpid(): # Don't kill ourselves
                    print(f"[{Fore.YELLOW}CLEANUP{Style.RESET_ALL}] Killing process {pid} on port {port}...", file=sys.stderr)
                    subprocess.run(f'taskkill /F /PID {pid}', shell=True, check=True, capture_output=True)
    except (subprocess.CalledProcessError, IndexError):
        # No process found or taskkill failed, which is fine
        pass

async def run_http_server():
    app = web.Application()
    app.router.add_get('/task', handle_get_task)
    app.router.add_post('/result', handle_post_result)
    runner = web.AppRunner(app)
    await runner.setup()
    site = web.TCPSite(runner, 'localhost', 8000)
    try:
        await site.start()
        print(f"[{Fore.CYAN}HTTP{Style.RESET_ALL}] Polling Bridge running on http://localhost:8000", file=sys.stderr)
    except OSError as e:
        if e.errno == 10048:
            print(f"{Fore.RED}[ERROR] Port 8000 is already in use.{Style.RESET_ALL}", file=sys.stderr)
            print(f"{Fore.YELLOW}[HINT] A previous instance of the server is still running. Please kill the process or wait a few seconds and restart Claude.{Style.RESET_ALL}", file=sys.stderr)
        raise

# --- Telemetry ---

async def telemetry_loop():
    while True:
        if state.last_poll_time:
            delta = (datetime.now() - state.last_poll_time).total_seconds()
            if delta < 5:
                print(f"{Fore.GREEN}[CONNECTED] Scilab Connected{Style.RESET_ALL} (last poll: {delta:.1f}s ago)", end="\r", file=sys.stderr)
            else:
                print(f"{Fore.RED}[DISCONNECTED] Awaiting Scilab Polling{Style.RESET_ALL} (idle for {delta:.1f}s)    ", end="\r", file=sys.stderr)
        else:
            print(f"{Fore.YELLOW}[INITIALIZING] Initializing Connection Status...{Style.RESET_ALL}            ", end="\r", file=sys.stderr)
        await asyncio.sleep(1)

# --- MCP Server Setup ---

mcp_server = Server("scilab-xcos-server")

@mcp_server.list_tools()
async def handle_list_tools() -> list[mcp_types.Tool]:
    return [
        mcp_types.Tool(
            name="get_xcos_block_data",
            description="Returns annotation JSON, reference XML, and parameter help for an Xcos block.",
            inputSchema={"type": "object", "properties": {"name": {"type": "string"}}, "required": ["name"]}
        ),
        mcp_types.Tool(
            name="get_xcos_block_source",
            description="Reads the raw Scilab .sci interface macro directly from the source code.",
            inputSchema={"type": "object", "properties": {"name": {"type": "string"}}, "required": ["name"]}
        ),
        mcp_types.Tool(
            name="search_related_xcos_files",
            description="Checks for any other files related to a specific block or keyword.",
            inputSchema={"type": "object", "properties": {"query": {"type": "string"}}, "required": ["query"]}
        ),
        mcp_types.Tool(
            name="verify_xcos_xml",
            description="Sends generated Xcos XML to an open Scilab instance for validation.",
            inputSchema={"type": "object", "properties": {"xml_content": {"type": "string"}}, "required": ["xml_content"]}
        ),
        mcp_types.Tool(
            name="xcos_start_draft",
            description="Starts a new incremental Xcos diagram draft session.",
            inputSchema={"type": "object", "properties": {"schema_version": {"type": "string", "default": "1.1"}}}
        ),
        mcp_types.Tool(
            name="xcos_add_blocks",
            description="Adds block XML elements to an active draft session.",
            inputSchema={"type": "object", "properties": {
                "session_id": {"type": "string"},
                "blocks_xml": {"type": "string"}
            }, "required": ["session_id", "blocks_xml"]}
        ),
        mcp_types.Tool(
            name="xcos_add_links",
            description="Adds link XML elements to an active draft session.",
            inputSchema={"type": "object", "properties": {
                "session_id": {"type": "string"},
                "links_xml": {"type": "string"}
            }, "required": ["session_id", "links_xml"]}
        ),
        mcp_types.Tool(
            name="xcos_verify_draft",
            description="Assembles the current draft and sends it to Scilab for verification.",
            inputSchema={"type": "object", "properties": {"session_id": {"type": "string"}}, "required": ["session_id"]}
        ),
        mcp_types.Tool(
            name="xcos_plan_phases",
            description="Call this first before generating any XML. Splits the diagram into named phases. Claude must complete one phase at a time and call xcos_commit_phase after each before proceeding to the next.",
            inputSchema={"type": "object", "properties": {
                "session_id": {"type": "string"},
                "phases": {"type": "array", "items": {"type": "string"}}
            }, "required": ["session_id", "phases"]}
        ),
        mcp_types.Tool(
            name="xcos_commit_phase",
            description="Call this after finishing each phase. Commits the generated XML to the file and signals that the next phase can begin. Do not start the next phase until this returns successfully.",
            inputSchema={"type": "object", "properties": {
                "session_id": {"type": "string"},
                "phase_label": {"type": "string"},
                "blocks_xml": {"type": "string"}
            }, "required": ["session_id", "phase_label", "blocks_xml"]}
        ),
    ]

@mcp_server.call_tool()
async def handle_call_tool(name: str, arguments: dict | None):
    if not arguments:
        return [mcp_types.TextContent(type="text", text="Error: Missing arguments")]
    
    if name == "get_xcos_block_data":
        return await get_xcos_block_data(arguments["name"])
    elif name == "get_xcos_block_source":
        return await get_xcos_block_source(arguments["name"])
    elif name == "search_related_xcos_files":
        return await search_related_xcos_files(arguments["query"])
    elif name == "verify_xcos_xml":
        return await verify_xcos_xml(arguments["xml_content"])
    elif name == "xcos_start_draft":
        return await xcos_start_draft(arguments.get("schema_version", "1.1"))
    elif name == "xcos_add_blocks":
        return await xcos_add_blocks(arguments["session_id"], arguments["blocks_xml"])
    elif name == "xcos_add_links":
        return await xcos_add_links(arguments["session_id"], arguments["links_xml"])
    elif name == "xcos_verify_draft":
        return await xcos_verify_draft(arguments["session_id"])
    elif name == "xcos_plan_phases":
        return await xcos_plan_phases(arguments["session_id"], arguments["phases"])
    elif name == "xcos_commit_phase":
        return await xcos_commit_phase(arguments["session_id"], arguments["phase_label"], arguments["blocks_xml"])
    else:
        return [mcp_types.TextContent(type="text", text=f"Unknown tool: {name}")]

async def main():
    # Attempt to clear port 8000 before starting
    await cleanup_port(8000)
    
    # Run the HTTP server and telemetry in the same loop
    async with stdio_server() as (read_stream, write_stream):
        await asyncio.gather(
            mcp_server.run(read_stream, write_stream, mcp_server.create_initialization_options()),
            run_http_server(),
            telemetry_loop()
        )

if __name__ == "__main__":
    asyncio.run(main())
