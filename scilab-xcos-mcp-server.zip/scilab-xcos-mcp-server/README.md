# Scilab Xcos MCP Server

A stateless, self-contained Python MCP server for Scilab Xcos engineering.

## Features
- **Dual-Server Design**: MCP stdio server for LLM tools + HTTP polling bridge (port 8000).
- **Automated Initialization**: `init.bat` auto-discovers Scilab and stages data.
- **Connection Telemetry**: Real-time CLI status (CONNECTED/DISCONNECTED) for Scilab connection.
- **Automated Polling**: `launch_scilab.bat` boots Scilab and starts the verification loop.

## Setup Instructions

### 1. Initialization
Run the initialization script to discover your Scilab installation and stage block data:
```batch
init.bat
```

### 2. Configure Claude Desktop
Add the following to your `claude_desktop_config.json`:

```json
{
  "mcpServers": {
    "scilab-xcos": {
      "command": "c:/Users/anton/Desktop/AI xcos module/.venv/Scripts/python.exe",
      "args": [
        "c:/Users/anton/Desktop/AI xcos module/scilab-xcos-mcp-server/server.py"
      ],
      "env": {
        "PYTHONPATH": "c:/Users/anton/Desktop/AI xcos module/scilab-xcos-mcp-server"
      }
    }
  }
}
```

### 3. Usage
1. Start the MCP server (it starts inside Claude Desktop automatically).
2. Run the Scilab polling launcher to enable verification:
```batch
launch_scilab.bat
```
3. Look for the `[CONNECTED] Scilab Connected` status in the terminal.

## Available Tools
- `get_xcos_block_example`: Get reference XML for a block.
- `get_xcos_block_source`: Read Scilab `.sci` macro.
- `get_xcos_block_info`: Get block annotation JSON.
- `get_xcos_block_help`: Extract parameter documentation.
- `search_related_xcos_files`: Search files in `./data/`.
- `verify_xcos_xml`: Send XML to Scilab for simulation validation.

## Troubleshooting & Best Practices

### 1. CMSCOPE Parameter Widths
When defining `realParameters` for a `CMSCOPE` block, ensure the width matches the number of channels:
- **1-channel**: `width=5` -> `[t_start, t_end, win_size, ymin, ymax]`
- **2-channel**: `width=7` -> `[t_start, t_end, win_size, ymin1, ymax1, ymin2, ymax2]`

### 2. Graphical Block Validation
- **Block Substitution**: Blocks that use `SCILAB` macros (like `BARXY`) are automatically substituted with a no-op function during validation to prevent hangs or crashes in headless mode. 
- **Warnings**: If substitution occurs, a `[WARN]` message will appear in the validation result to indicate that graphical behavior was skipped.

### 3. Simulation Time for Validation
To ensure rapid feedback, the validator overrides the diagram's `finalIntegrationTime` to **0.1s** during the `verify_xcos_xml` tool call. This is sufficient to catch structural and parameter errors without waiting for a long simulation to complete.
