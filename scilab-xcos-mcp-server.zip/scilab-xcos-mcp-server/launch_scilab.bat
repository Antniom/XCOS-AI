@echo off
setlocal enabledelayedexpansion

echo ################################################
echo # Scilab Xcos Polling Launcher                 #
echo ################################################

if not exist ".scilab_path" (
    echo [!] .scilab_path not found. Please run init.bat first.
    pause
    exit /b 1
)

:: Read the path correctly, preserving spaces
set "SCILAB_ROOT="
for /f "usebackq tokens=*" %%a in (".scilab_path") do (
    set "SCILAB_ROOT=%%a"
)

:: Trim trailing spaces (if any)
:trim
if "!SCILAB_ROOT:~-1!"==" " (
    set "SCILAB_ROOT=!SCILAB_ROOT:~0,-1!"
    goto trim
)

set "SCI_BIN=!SCILAB_ROOT!\bin\WScilex-cli.exe"

if not exist "!SCI_BIN!" (
    echo [!] Scilab executable not found at: "!SCI_BIN!"
    echo [!] Check .scilab_path or run init.bat again.
    pause
    exit /b 1
)

echo [LAUNCH] Starting Scilab Polling Loop (Background)...
echo [INFO] Scilab will run in CLI mode. Close this window to stop if needed.

:: Run WITHOUT -nw as it is no longer supported in Scilab 2026.0.1
"!SCI_BIN!" -f start_poll.sce

if %ERRORLEVEL% NEQ 0 (
    echo [!] Scilab exited with error %ERRORLEVEL%
    pause
)
